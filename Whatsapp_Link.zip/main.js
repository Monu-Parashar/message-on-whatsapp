var dis = document.getElementById("main");
var ln = document.getElementById("link");
var c = document.getElementById("code");
var n = document.getElementById("number");
var me = document.getElementById("mes").style;
var wh = document.getElementById("what").style;


var li = "https://wa.me/";



function load() { dis.style.display = "grid";}
function lnk(){return li+c.value+n.value;}
function kyup() { ln.value = lnk();}
function opn() { window.open(lnk());}
function mes() {
  me.display = "grid";
   if (false) {
    alert("hii");
  } else { alert(wh.display);}
}
function cpy() {
  ln.select();
  ln.setSelectionRange(0, 99999);
  document.execCommand("copy");
}

load();